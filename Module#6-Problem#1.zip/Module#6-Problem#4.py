import math

math.pi
print(math.pi)

