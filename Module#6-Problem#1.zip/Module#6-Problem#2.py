import random

random.randrange(0,100)
myList=[0,100]
for numbers in range(0,100):
 print(range)
 print(0,100)
