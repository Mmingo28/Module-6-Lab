import math

#math.factorial
factorial = int(input("What is the value of x?"))
print(math.factorial(factorial))

